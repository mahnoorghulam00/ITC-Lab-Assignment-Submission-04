// Name : Mahnoor Ghulam Muhammad
//roll num: 0091
/*
                                                  TASK1
#include<iostream>
using name space std;
int main()
{
        int num;
        cout<<"enter an interger:";
        cin>>num;
        if(num>0)
        {
           cout<<"Num is positive"<<endl;
           }
           return 0;
  }
  */


/*
                                                                       TASK2
  /*#include<iostream>
  using namespace std;
  int main()
  {
      int bill_amount;
      cout << "Enter bill amount:";
      cin >> bill_amount;
      if (bill_amount >= 5000)
      {
          cout << "Qualified for discount" << endl;
      }        //i check all the cases and run with 4999,5000,6500
      return 0;
  }
  */

  /*
                                                                     TASK3
   #include<iostream>
  using namespace std;
  int main()
  {
      int num;
      cout << "Enter any num:";
      cin >> num;
      if (num % 2 == 0)
      {
          cout << "Even" << endl;

      }
      else
      {
          cout << "Odd" << endl;
      }
      return 0;
  }
  */

  /*
                                                                      TASK4
  #include<iostream>
  using namespace std;
  int main()
  {
      int age;
      cout << "enter the age:" << endl;
      cin >> age;
      if (age <= 18)
      {
          cout << "Eligible" << endl;

      }
      else
      {
          cout << "Not eligible" << endl;
      }
      return 0;
  }
  */

  /*
                                                                        TASK5
  #include<iostream>
  using namespace std;
  int main()
  {
      int num1;
      int num2;
      cout << " enter num1:";
      cin >> num1;
      cout << "enter num2:";
      cin >> num2;
      if (num1 > num2)
      {
          cout << "first num is greater" << endl;
      }
      else
      {
          cout << "sec num id greater" << endl;
      }
      return 0;
  }
  */

  /*
                                                                         TASK6
  #include<iostream>
  using namespace std;
  int main()
  {
      int marks;
      cout << "enter the marks";
      cin >> marks;
      if (marks >= 90 && marks <= 100)
      {
          cout << "A" << endl;
      }
      else if (marks<90&&marks>=80)
      {
          cout << "A";
      }
      else if (marks<80&&marks>=70)
      {
          cout << "B";
      }
      else if (marks<70&&marks>=60)
      {
          cout << "C";
      }
      else
      {
          cout << "fail";
      }
      return 0;
  }
  */

  /*
                                                            TASK7
  #include<iostream>
  using namespace std;
  int main()
  {
      int tem;
      cout << "Enter the tem";
      cin >> tem;
      if (tem < 10)
      {
          cout << "Cold";
      }
      else if (tem < 25)
      {
          cout << "Pleasant";
      }
      else if (tem < 35)
      {
          cout << "Warm";
      }
      else
      {
          cout<<"Hot";
      }
      return 0;
  }
  */

/*
                                                                   TASK8
   #include <iostream>
using namespace std;
  int main()
  {
      int marks;
      cout << "Enter marks: ";
      cin >> marks;
      if (marks>=50)
      {
          cout << "Pass" << endl;
      }
      else
      {
          cout << "Fail" << endl;
      }
      return 0;
  //== is a sign of relational operator .it chect two value is equal or not Relational operator compare two values to determine the relationship between the values .
  //= is a sign of assignment operator .it is used to assign a value to a variable.
  }
  */
  
/*
                                                                   TASK9
#include<iostream>
using namespace std;
int main()
{
    int units;
    cout << "Enter units:";
        cin >> units;
        if (units <= 100)
        {
            cout << "low usage" << endl;
        }
        else if (units <= 300)
        {
            cout << "medium uasge" << endl;
        }
        else
        {
            cout<<"High usage" << endl;
        }
        return 0;
}
*/

/*
                                                            TASK 10
#include<iostream>
using namespace std;
int main()
{
    int marks;
    cout << "Enter the marks:";
        cin >> marks;
        if (marks >= 85)
        {
            cout << " Scholarship awarded" << endl;
        }
        else
        {
            cout << " Scholarship not awarded" << endl;
        }
        return 0;
}
*/



/*
                                                                  TASK 11
#include <iostream>
using namespace std;
int main() {
    int visitorAge;
    cout << "Enter visitor age: ";
    cin >> visitorAge;
    if (visitorAge < 0) 
    {
        cout << "Invalid age" << endl;
    }
    else if (visitorAge < 5)
    {
        cout << "Free entry" << endl;
    }
    else if (visitorAge <= 17) 
    {
        cout << "Child/Student ticket: Rs. 200" << endl;
    }
    else if (visitorAge <= 59) 
    {
        cout << "Adult ticket: Rs. 500" << endl;
    }
    else 
{
        cout << "Senior ticket: Rs. 300" << endl;
    }

    return 0;
}

*/

